#include "BSAI25020-Displaying.h"
#include "BSAI25020-Board.h"
#include "BSAI25020-Player.h"
#include "BSAI25020-Game.h"
#include <iostream>

Displaying::Displaying() : screenWidth(1200), screenHeight(800), cellSize(40) {}

Displaying::Displaying(int w, int h, int cs)
    : screenWidth(w), screenHeight(h), cellSize(cs) {}

void Displaying::drawBoard(const Board* b) const {
    // TODO: Replace with Raylib DrawRectangle/DrawText calls
    // Stub: prints board dimensions
    if (b == nullptr) return;
    std::cout << "[Displaying] drawBoard called. Total cells: " << b->getCellCount() << "\n";
}

void Displaying::drawPieces(const Player* players, int n) const {
    // TODO: Replace with Raylib DrawCircle calls per piece position
    if (players == nullptr) return;
    std::cout << "[Displaying] drawPieces called for " << n << " players.\n";
}

void Displaying::drawDice(int roll) const {
    // TODO: Replace with Raylib texture/shape draw for dice face
    std::cout << "[Displaying] drawDice: rolled " << roll << "\n";
}

void Displaying::drawUI(const Game* g) const {
    // TODO: Replace with Raylib panel drawing
    if (g == nullptr) return;
    std::cout << "[Displaying] drawUI called.\n";
}
