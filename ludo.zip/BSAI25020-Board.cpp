#include "BSAI25020-Board.h"

static const int SAFE_TRACK_POS[] = {0, 8, 13, 21, 26, 34, 39, 47};
static const int SAFE_COUNT = 8;

static const int HOME_ENTRY_TRACK[] = {
    50,
    11,
    24,
    37,
    50,
    5
};

static const int START_TRACK_POS[] = {
    0,
    13,
    26,
    39,
    6,
    19
};

static const int HOME_COL_BASE_ID[] = {
    52,
    58,
    64,
    70,
    76,
    82
};

static const int BASE_CELL_START[] = {
    89,
    93,
    97,
    101,
    105,
    109
};

Board::Board() : cellCount(TOTAL_CELLS) {
    cells.resize(TOTAL_CELLS);
    initBoard();
}

void Board::initBoard() {

    for (int i = 0; i < TRACK_SIZE; i++) {
        cells[i] = Cell(i, false, false, NONE_COLOUR, false, false);
    }

    markSafeSquares();
    markHomeColumns();
    markBaseCells();

    cells[CENTRE_CELL_ID] = Cell(CENTRE_CELL_ID, true, false, NONE_COLOUR, true, false);
}

void Board::markSafeSquares() {
    for (int i = 0; i < SAFE_COUNT; i++) {
        int id = SAFE_TRACK_POS[i];
        cells[id] = Cell(id, true, false, NONE_COLOUR, false, false);
    }
}

void Board::markHomeColumns() {
    for (int c = 0; c < MAX_COLOURS; c++) {
        int base = HOME_COL_BASE_ID[c];
        for (int j = 0; j < HOME_COL_LEN; j++) {
            int id = base + j;
            cells[id] = Cell(id, true, true, (Colour)c, false, false);
        }
    }
}

void Board::markBaseCells() {
    for (int c = 0; c < MAX_COLOURS; c++) {
        int base = BASE_CELL_START[c];
        for (int j = 0; j < MAX_PIECES; j++) {
            int id = base + j;
            cells[id] = Cell(id, true, false, (Colour)c, false, true);
        }
    }
}

Cell* Board::getCell(int id) {
    if (id < 0 || id >= TOTAL_CELLS) return nullptr;
    return &cells[id];
}

const Cell* Board::getCell(int id) const {
    if (id < 0 || id >= TOTAL_CELLS) return nullptr;
    return &cells[id];
}

bool Board::isSafeSquare(int pos) const {
    const Cell* c = getCell(pos);
    if (c == nullptr) return false;
    return c->isSafeSquare();
}

bool Board::isHomeColumn(int pos, Colour c) const {
    const Cell* cell = getCell(pos);
    if (cell == nullptr) return false;
    return cell->getIsHomeColumn() && cell->getHomeColourOwner() == c;
}

int Board::getStartPosition(Colour c) const {
    if (c < 0 || c >= MAX_COLOURS) return -1;
    return START_TRACK_POS[c];
}

int Board::getHomeColumnEntry(Colour c) const {
    if (c < 0 || c >= MAX_COLOURS) return -1;
    return HOME_ENTRY_TRACK[c];
}

int Board::trackPosToCell(int trackPos) const {
    return ((trackPos % TRACK_SIZE) + TRACK_SIZE) % TRACK_SIZE;
}

int Board::getDestination(int currentCellId, int roll, Colour c) const {
    if (c < 0 || c >= MAX_COLOURS) return -1;
    if (currentCellId < 0) return -1;

    int colourIdx = (int)c;
    int homeColBase = HOME_COL_BASE_ID[colourIdx];
    int homeEntry   = HOME_ENTRY_TRACK[colourIdx];

    if (currentCellId >= homeColBase && currentCellId < homeColBase + HOME_COL_LEN) {
        int posInHomeCol = currentCellId - homeColBase;
        int target = posInHomeCol + roll;
        if (target == HOME_COL_LEN) {
            return CENTRE_CELL_ID;
        } else if (target < HOME_COL_LEN) {
            return homeColBase + target;
        } else {
            return -1;
        }
    }

    if (currentCellId == CENTRE_CELL_ID) {
        return -1;
    }

    int trackPos = currentCellId;

    int distToEntry = (homeEntry - trackPos + TRACK_SIZE) % TRACK_SIZE + 1;

    if (roll < distToEntry) {

        int newTrackPos = (trackPos + roll) % TRACK_SIZE;
        return newTrackPos;
    } else if (roll == distToEntry) {

        return homeColBase;
    } else {

        int overshootInHomeCol = roll - distToEntry;

        if (overshootInHomeCol == HOME_COL_LEN) {
            return CENTRE_CELL_ID;
        } else if (overshootInHomeCol < HOME_COL_LEN) {
            return homeColBase + overshootInHomeCol;
        } else {
            return -1;
        }
    }
}

int Board::getCellCount() const {
    return cellCount;
}

int Board::getBaseCellId(Colour c, int pieceIndex) const {
    if (c < 0 || c >= MAX_COLOURS) return -1;
    if (pieceIndex < 0 || pieceIndex >= MAX_PIECES) return -1;
    return BASE_CELL_START[(int)c] + pieceIndex;
}

int Board::getCentreCellId() const {
    return CENTRE_CELL_ID;
}
