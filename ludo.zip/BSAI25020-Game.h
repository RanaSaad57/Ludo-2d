#pragma once
#include <string>
#include <vector>
#include "BSAI25020-Enums.h"
#include "BSAI25020-Board.h"
#include "BSAI25020-Dice.h"
#include "BSAI25020-History.h"
#include "BSAI25020-GameState.h"
#include "BSAI25020-Helpers.h"

class Player;
class HumanPlayer;

static const int GAME_MAX_PLAYERS = 6;

class Game {
private:
    Player* players[GAME_MAX_PLAYERS];
    int playerCount;
    Board board;
    Dice dice;
    History history;
    GameState initialState;
    int currentPlayer;
    bool replayMode;
    AppState appstate;
    std::vector<GameState> Gamestates;
    Helpers helpers;

    void applyState(const GameState& gs);
    GameState captureState() const;
    void advancePlayer();
    bool isPlayerActive(int idx) const;
    bool checkCapture_return(int pos, Player* mover, int& capPieceNo, int& capPlayerId);

public:
    Game();
    ~Game();

    void startGame(int playerCount);
    void takeTurn();

    void roll(int roll);

    void movePiece(Player* t, int roll);

    void checkCapture(int pos, Player* mover);
    bool checkWin();

    void undoMove();
    void redoMove();
    void startReplay();
    void stepReplayForward();
    void stepReplayBackward();

    void saveGame(const std::string& filename);
    void loadGame(const std::string& filename);
    void saveHistory();

    void changeAppState(AppState ap);
    AppState getAppState() const;
    int getCurrentPlayer() const;
    Player* getPlayer(int idx) const;
    int getPlayerCount() const;
    const Board* getBoard() const;
    const Dice* getDice() const;
    const History* getHistory() const;
    bool isReplayMode() const;
};
