#include "BSAI25020-Cell.h"
#include "BSAI25020-Piece.h"
#include <algorithm>

Cell::Cell()
    : cellId(-1), isSafe(false), isHomeColumn(false),
      isHomeCOlourOwner(false), homeColourOwner(NONE_COLOUR),
      isCentre(false), isBase(false) {}

Cell::Cell(int id, bool safe, bool homeCol, Colour owner, bool centre, bool base)
    : cellId(id), isSafe(safe), isHomeColumn(homeCol),
      isHomeCOlourOwner(owner != NONE_COLOUR), homeColourOwner(owner),
      isCentre(centre), isBase(base) {}

int Cell::getCellId() const {
    return cellId;
}

bool Cell::isSafeSquare() const {
    return isSafe;
}

bool Cell::canEnter(Colour c) const {

    if (isHomeColumn) {
        return homeColourOwner == c;
    }

    return true;
}

void Cell::addPiece(Piece* p) {
    if (p != nullptr) {
        pieces.push_back(p);
    }
}

void Cell::removePiece(Piece* p) {
    for (int i = 0; i < (int)pieces.size(); i++) {
        if (pieces[i] == p) {
            pieces.erase(pieces.begin() + i);
            return;
        }
    }
}

const std::vector<Piece*>& Cell::getPieces() const {
    return pieces;
}

std::vector<Piece*>& Cell::getPieces() {
    return pieces;
}

bool Cell::getIsHomeColumn() const {
    return isHomeColumn;
}

bool Cell::getIsCentre() const {
    return isCentre;
}

bool Cell::getIsBase() const {
    return isBase;
}

Colour Cell::getHomeColourOwner() const {
    return homeColourOwner;
}

bool Cell::isEmpty() const {
    return pieces.empty();
}

int Cell::getPieceCount() const {
    return (int)pieces.size();
}
