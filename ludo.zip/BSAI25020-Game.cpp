#include "BSAI25020-Game.h"
#include "BSAI25020-Player.h"
#include "BSAI25020-HumanPlayer.h"
#include "BSAI25020-MoveRecord.h"
#include <iostream>

Game::Game()
    : playerCount(0), currentPlayer(0), replayMode(false), appstate(MENU) {
    for (int i = 0; i < GAME_MAX_PLAYERS; i++) {
        players[i] = nullptr;
    }
}

Game::~Game() {
    for (int i = 0; i < GAME_MAX_PLAYERS; i++) {
        delete players[i];
        players[i] = nullptr;
    }
}

void Game::startGame(int count) {
    if (count < 2) count = 2;
    if (count > GAME_MAX_PLAYERS) count = GAME_MAX_PLAYERS;
    playerCount = count;

    for (int i = 0; i < GAME_MAX_PLAYERS; i++) {
        delete players[i];
        players[i] = nullptr;
    }

    Colour colours[] = { RED, GREEN, YELLOW, BLUE, PURPLE, ORANGE };
    std::string defaultNames[] = { "Red", "Green", "Yellow", "Blue", "Purple", "Orange" };

    for (int i = 0; i < playerCount; i++) {
        players[i] = new HumanPlayer(defaultNames[i], colours[i]);
    }

    history.clear();
    Gamestates.clear();
    currentPlayer = 0;
    dice.reset();
    appstate = PLAYING;

    for (int p = 0; p < playerCount; p++) {
        Colour c = players[p]->getColour();
        for (int j = 0; j < MAX_PIECES; j++) {
            int baseCellId = board.getBaseCellId(c, j);
            Piece* piece = players[p]->getPiece(j);
            piece->reset();
            piece->setPosition(baseCellId);
            Cell* cell = board.getCell(baseCellId);
            if (cell != nullptr) cell->addPiece(piece);
        }
    }

    initialState = captureState();
}

void Game::takeTurn() {
    while (isPlayerActive(currentPlayer) == false && playerCount > 0) {
        advancePlayer();
    }
}

void Game::advancePlayer() {
    currentPlayer = (currentPlayer + 1) % playerCount;
}

bool Game::isPlayerActive(int idx) const {
    if (idx < 0 || idx >= playerCount || players[idx] == nullptr) return false;
    return !players[idx]->allFinished();
}

void Game::roll(int rollVal) {
    if (dice.getConsecutiveSixes() >= 3) {
        std::cout << "Three consecutive sixes! Turn forfeited.\n";
        advancePlayer();
        dice.reset();
        return;
    }
}

void Game::movePiece(Player* mover, int rollVal) {
    if (mover == nullptr) return;

    Piece* chosen = nullptr;
    int chosenIdx = -1;
    for (int i = 0; i < MAX_PIECES; i++) {
        Piece* p = mover->getPiece(i);
        if (p != nullptr && Helpers::isValidMove(p, rollVal, &board)) {
            chosen = p;
            chosenIdx = i;
            break;
        }
    }

    if (chosen == nullptr) {
        std::cout << "No valid move. Turn passes.\n";
        advancePlayer();
        return;
    }

    int src = chosen->getPosition();
    int dest = -1;

    if (chosen->getState() == BASE) {
        Cell* baseCell = board.getCell(src);
        if (baseCell != nullptr) baseCell->removePiece(chosen);

        dest = board.getStartPosition(mover->getColour());
        chosen->setPosition(dest);
        chosen->setState(ACTIVE);
    } else {
        Cell* srcCell = board.getCell(src);
        if (srcCell != nullptr) srcCell->removePiece(chosen);

        dest = board.getDestination(src, rollVal, mover->getColour());
        chosen->setPosition(dest);

        if (dest == board.getCentreCellId()) {
            chosen->setState(FINISHED);
        } else {
            const Cell* destCell = board.getCell(dest);
            if (destCell != nullptr && destCell->getIsHomeColumn()) {
                chosen->setState(HOME_COL);
            } else {
                chosen->setState(ACTIVE);
            }
        }
    }

    Cell* destCell = board.getCell(dest);
    if (destCell != nullptr) destCell->addPiece(chosen);

    bool captured = false;
    int capPieceNo = -1;
    int capPlayerId = -1;

    if (!board.isSafeSquare(dest) && chosen->getState() == ACTIVE) {
        captured = checkCapture_return(dest, mover, capPieceNo, capPlayerId);
    }

    int playerIdx = -1;
    for (int i = 0; i < playerCount; i++) {
        if (players[i] == mover) {
            playerIdx = i;
            break;
        }
    }

    MoveRecord rec(chosenIdx, playerIdx, src, dest, rollVal,
                   captured, capPieceNo, capPlayerId);
    GameState gs = captureState();
    gs.moveNumber = history.getTotalMoves() + 1;
    history.push(rec, gs);
    Gamestates.push_back(gs);

    bool bonusTurn = (rollVal == 6) || captured;
    if (!bonusTurn) {
        advancePlayer();
    }

    checkWin();
}

void Game::checkCapture(int pos, Player* mover) {
    int dummy1, dummy2;
    checkCapture_return(pos, mover, dummy1, dummy2);
}

bool Game::checkCapture_return(int pos, Player* mover, int& capPieceNo, int& capPlayerId) {
    Cell* cell = board.getCell(pos);
    if (cell == nullptr || board.isSafeSquare(pos)) return false;

    std::vector<Piece*>& piecesOnCell = cell->getPieces();
    for (int i = (int)piecesOnCell.size() - 1; i >= 0; i--) {
        Piece* p = piecesOnCell[i];
        if (p == nullptr) continue;
        if (p->getColour() == mover->getColour()) continue;

        capPieceNo = p->getPieceN();

        for (int pi = 0; pi < playerCount; pi++) {
            if (players[pi] == nullptr) continue;
            if (players[pi]->getColour() == p->getColour()) {
                capPlayerId = pi;
                break;
            }
        }

        piecesOnCell.erase(piecesOnCell.begin() + i);

        int baseId = board.getBaseCellId(p->getColour(), capPieceNo);
        p->reset();
        p->setPosition(baseId);
        Cell* baseCell = board.getCell(baseId);
        if (baseCell != nullptr) baseCell->addPiece(p);

        return true;
    }
    return false;
}

bool Game::checkWin() {
    for (int i = 0; i < playerCount; i++) {
        if (players[i] != nullptr && players[i]->allFinished()) {
            std::cout << players[i]->getName() << " wins!\n";
            appstate = GAMEOVER;
            return true;
        }
    }
    return false;
}

void Game::undoMove() {
    MoveRecord* rec = history.undo();
    if (rec == nullptr) return;

    int undoIdx = history.getUndoIndex();
    const GameState* prev = (undoIdx >= 0) ? history.getState(undoIdx) : &initialState;
    if (prev != nullptr) applyState(*prev);
}

void Game::redoMove() {
    MoveRecord* rec = history.redo();
    if (rec == nullptr) return;

    const GameState* next = history.getState(history.getUndoIndex());
    if (next != nullptr) applyState(*next);
}

void Game::startReplay() {
    replayMode = true;
    applyState(initialState);
}

void Game::stepReplayForward() {
    if (!replayMode) return;
    MoveRecord* rec = history.redo();
    if (rec == nullptr) {
        replayMode = false;
        return;
    }
    const GameState* st = history.getState(history.getUndoIndex());
    if (st != nullptr) applyState(*st);
}

void Game::stepReplayBackward() {
    if (!replayMode) return;
    MoveRecord* rec = history.undo();
    if (rec == nullptr) return;
    int idx = history.getUndoIndex();
    const GameState* st = (idx >= 0) ? history.getState(idx) : &initialState;
    if (st != nullptr) applyState(*st);
}

void Game::saveGame(const std::string& filename) {
    helpers.save(history, filename);
}

void Game::loadGame(const std::string& filename) {
    int pc = 0;
    std::string names[GAME_MAX_PLAYERS];
    Colour colours[GAME_MAX_PLAYERS];
    bool humans[GAME_MAX_PLAYERS];
    GameState loaded;

    if (!helpers.load(filename, history, loaded, pc, names, colours, humans)) {
        std::cout << "Failed to load save file: " << filename << "\n";
        return;
    }

    for (int i = 0; i < GAME_MAX_PLAYERS; i++) {
        delete players[i];
        players[i] = nullptr;
    }
    playerCount = pc;
    for (int i = 0; i < playerCount; i++) {
        players[i] = new HumanPlayer(names[i], colours[i]);
    }

    applyState(loaded);
    appstate = PLAYING;
}

void Game::saveHistory() {
    helpers.save(history, "autosave.txt");
}

GameState Game::captureState() const {
    GameState gs;
    gs.currentPlayerIndex = currentPlayer;
    gs.consecutiveSixes = dice.getConsecutiveSixes();
    gs.moveNumber = history.getTotalMoves();
    for (int p = 0; p < playerCount && p < MAX_PLAYERS; p++) {
        if (players[p] == nullptr) continue;
        for (int j = 0; j < MAX_PIECES; j++) {
            const Piece* piece = players[p]->getPiece(j);
            if (piece != nullptr) {
                gs.piecePositions[p][j] = piece->getPosition();
                gs.pieceStates[p][j] = piece->getState();
            }
        }
    }
    return gs;
}

void Game::applyState(const GameState& gs) {
    currentPlayer = gs.currentPlayerIndex;

    for (int id = 0; id < board.getCellCount(); id++) {
        Cell* cell = board.getCell(id);
        if (cell != nullptr) cell->getPieces().clear();
    }

    for (int p = 0; p < playerCount && p < MAX_PLAYERS; p++) {
        if (players[p] == nullptr) continue;
        for (int j = 0; j < MAX_PIECES; j++) {
            Piece* piece = players[p]->getPiece(j);
            if (piece == nullptr) continue;
            piece->setPosition(gs.piecePositions[p][j]);
            piece->setState(gs.pieceStates[p][j]);
            int pos = gs.piecePositions[p][j];
            Cell* cell = board.getCell(pos);
            if (cell != nullptr) cell->addPiece(piece);
        }
    }
}

void Game::changeAppState(AppState ap) {
    appstate = ap;
}

AppState Game::getAppState() const {
    return appstate;
}

int Game::getCurrentPlayer() const {
    return currentPlayer;
}

Player* Game::getPlayer(int idx) const {
    if (idx < 0 || idx >= playerCount) return nullptr;
    return players[idx];
}

int Game::getPlayerCount() const {
    return playerCount;
}

const Board* Game::getBoard() const {
    return &board;
}

const Dice* Game::getDice() const {
    return &dice;
}

const History* Game::getHistory() const {
    return &history;
}

bool Game::isReplayMode() const {
    return replayMode;
}
