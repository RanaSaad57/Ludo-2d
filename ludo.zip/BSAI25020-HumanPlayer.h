#pragma once
#include "BSAI25020-Player.h"

class HumanPlayer : public Player {
public:
    HumanPlayer();
    HumanPlayer(const std::string& n, Colour c);
    ~HumanPlayer() override;

    int getMove() override;
};
