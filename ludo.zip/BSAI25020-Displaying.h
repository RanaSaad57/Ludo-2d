#pragma once

class Board;
class Player;
class Dice;
class Game;

// Displaying: all Raylib rendering lives here.
// Reads from Game/Board/Players but NEVER modifies them.
// Completely decoupled from logic so rules work without a window.

class Displaying {
private:
    int screenWidth;
    int screenHeight;
    int cellSize;

public:
    Displaying();
    Displaying(int w, int h, int cs);

    void drawBoard(const Board* b) const;
    void drawPieces(const Player* players, int n) const;
    void drawDice(int roll) const;
    void drawUI(const Game* g) const;
};
