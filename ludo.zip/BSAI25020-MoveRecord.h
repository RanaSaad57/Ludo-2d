#pragma once
#include "BSAI25020-Enums.h"

struct MoveRecord {
    int pieceNo;
    int playerId;
    int source;
    int dest;
    int capturedPieceNo;
    int capturedPlayerId;
    int diceValue;
    bool wasCapture;

    MoveRecord();
    MoveRecord(int pNo, int pId, int src, int dst, int diceVal,
               bool capture = false, int capPieceNo = -1, int capPlayerId = -1);

    bool wasCapture_() const;
};
