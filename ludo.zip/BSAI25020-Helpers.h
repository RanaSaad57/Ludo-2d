#pragma once
#include <string>
#include "BSAI25020-Enums.h"
#include "BSAI25020-History.h"
#include "BSAI25020-GameState.h"

class Piece;
class Board;
class Player;

class Helpers {
public:
    Helpers();

    static bool canOpen(int roll);
    static bool isValidMove(const Piece* t, int roll, const Board* b);
    static bool hasAnyValidMove(const Player* p, int roll, const Board* b);

    void save(const History& hs, const std::string& filename) const;
    bool load(const std::string& filename, History& hs, GameState& initialState,
              int& playerCount, std::string playerNames[], Colour playerColours[],
              bool playerIsHuman[]) const;

    int getPieceChoice(const Player* p) const;
    bool waitForRoll() const;
    int getMenuChoice() const;
};
