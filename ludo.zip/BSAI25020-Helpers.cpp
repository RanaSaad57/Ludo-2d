#include "BSAI25020-Helpers.h"
#include "BSAI25020-Piece.h"
#include "BSAI25020-Board.h"
#include "BSAI25020-Cell.h"
#include "BSAI25020-Player.h"
#include "BSAI25020-MoveRecord.h"
#include <fstream>
#include <sstream>
#include <iostream>

Helpers::Helpers() {}

bool Helpers::canOpen(int roll) {
    return roll == 6;
}

bool Helpers::isValidMove(const Piece* t, int roll, const Board* b) {
    if (t == nullptr || b == nullptr) return false;

    PieceState state = t->getState();
    Colour c = t->getColour();

    if (state == BASE) {
        return canOpen(roll);
    }

    if (state == FINISHED) {
        return false;
    }

    int dest = b->getDestination(t->getPosition(), roll, c);
    if (dest == -1) return false;

    const Cell* destCell = b->getCell(dest);
    if (destCell == nullptr) return false;
    if (!destCell->canEnter(c)) return false;

    return true;
}

bool Helpers::hasAnyValidMove(const Player* p, int roll, const Board* b) {
    if (p == nullptr || b == nullptr) return false;
    for (int i = 0; i < MAX_PIECES; i++) {
        const Piece* piece = p->getPiece(i);
        if (piece != nullptr && isValidMove(piece, roll, b)) {
            return true;
        }
    }
    return false;
}

void Helpers::save(const History& hs, const std::string& filename) const {
    std::ofstream out(filename);
    if (!out.is_open()) return;

    int total = hs.getTotalMoves();
    out << "LUDO_SAVE_V1\n";
    out << "HISTORY_COUNT " << total << "\n";

    for (int i = 0; i < total; i++) {
        const MoveRecord* rec = hs.getRecord(i);
        const GameState* st = hs.getState(i);
        if (rec == nullptr || st == nullptr) continue;

        out << "MOVE "
            << rec->pieceNo << " "
            << rec->playerId << " "
            << rec->source << " "
            << rec->dest << " "
            << rec->diceValue << " "
            << (rec->wasCapture ? 1 : 0) << " "
            << rec->capturedPieceNo << " "
            << rec->capturedPlayerId << "\n";

        out << "STATE "
            << st->currentPlayerIndex << " "
            << st->consecutiveSixes << " "
            << st->moveNumber << "\n";

        out << "PIECE_STATES";
        for (int p = 0; p < MAX_PLAYERS; p++) {
            for (int j = 0; j < PIECES_PER_PLAYER; j++) {
                out << " " << (int)st->pieceStates[p][j];
            }
        }
        out << "\n";

        out << "PIECE_POS";
        for (int p = 0; p < MAX_PLAYERS; p++) {
            for (int j = 0; j < PIECES_PER_PLAYER; j++) {
                out << " " << st->piecePositions[p][j];
            }
        }
        out << "\n";
    }

    out << "END_SAVE\n";
    out.close();
}

bool Helpers::load(const std::string& filename, History& hs, GameState& initialState,
                   int& playerCount, std::string playerNames[], Colour playerColours[],
                   bool playerIsHuman[]) const {
    std::ifstream in(filename);
    if (!in.is_open()) return false;

    std::string line;
    if (!std::getline(in, line) || line != "LUDO_SAVE_V1") return false;

    hs.clear();
    int historyCount = 0;

    while (std::getline(in, line)) {
        if (line == "END_SAVE") break;

        std::istringstream ss(line);
        std::string token;
        ss >> token;

        if (token == "HISTORY_COUNT") {
            ss >> historyCount;
        } else if (token == "MOVE") {
            MoveRecord rec;
            int cap;
            ss >> rec.pieceNo >> rec.playerId >> rec.source >> rec.dest
               >> rec.diceValue >> cap >> rec.capturedPieceNo >> rec.capturedPlayerId;
            rec.wasCapture = (cap == 1);

            GameState st;
            std::getline(in, line);
            std::istringstream ss2(line);
            std::string tok2;
            ss2 >> tok2;
            ss2 >> st.currentPlayerIndex >> st.consecutiveSixes >> st.moveNumber;

            std::getline(in, line);
            std::istringstream ss3(line);
            std::string tok3;
            ss3 >> tok3;
            for (int p = 0; p < MAX_PLAYERS; p++) {
                for (int j = 0; j < PIECES_PER_PLAYER; j++) {
                    int ps;
                    ss3 >> ps;
                    st.pieceStates[p][j] = (PieceState)ps;
                }
            }

            std::getline(in, line);
            std::istringstream ss4(line);
            std::string tok4;
            ss4 >> tok4;
            for (int p = 0; p < MAX_PLAYERS; p++) {
                for (int j = 0; j < PIECES_PER_PLAYER; j++) {
                    ss4 >> st.piecePositions[p][j];
                }
            }

            hs.push(rec, st);
        }
    }

    in.close();
    return true;
}

int Helpers::getPieceChoice(const Player* p) const {
    if (p == nullptr) return -1;
    std::cout << "Choose piece to move (0-3): ";
    int choice = -1;
    std::cin >> choice;
    if (choice < 0 || choice >= MAX_PIECES) return -1;
    return choice;
}

bool Helpers::waitForRoll() const {
    std::cout << "Press Enter to roll dice...";
    std::cin.ignore();
    std::cin.get();
    return true;
}

int Helpers::getMenuChoice() const {
    std::cout << "1=New Game  2=Load  3=Replay  4=Quit\nChoice: ";
    int choice = 0;
    std::cin >> choice;
    return choice;
}
