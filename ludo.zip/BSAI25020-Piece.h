#pragma once
#include "BSAI25020-Enums.h"

class Piece {
private:
    int pieceNo;
    Colour colour;
    int position;
    PieceState state;

public:
    Piece();
    Piece(int no, Colour c);

    int getPosition() const;
    int getPieceN() const;
    Colour getColour() const;
    PieceState getState() const;

    void setState(PieceState s);
    void setPosition(int pos);
    bool isFinished() const;
    void reset();
};
