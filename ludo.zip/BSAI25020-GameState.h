#pragma once
#include <vector>
#include "BSAI25020-Enums.h"

static const int MAX_PLAYERS = 6;
static const int PIECES_PER_PLAYER = 4;

struct GameState {

    int piecePositions[MAX_PLAYERS][PIECES_PER_PLAYER];
    PieceState pieceStates[MAX_PLAYERS][PIECES_PER_PLAYER];
    int currentPlayerIndex;
    int consecutiveSixes;
    int moveNumber;

    GameState();
    GameState(const GameState& other);
    GameState& operator=(const GameState& other);
};
