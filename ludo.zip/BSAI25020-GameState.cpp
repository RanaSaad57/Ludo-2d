#include "BSAI25020-GameState.h"
#include <cstring>

GameState::GameState() : currentPlayerIndex(0), consecutiveSixes(0), moveNumber(0) {
    for (int p = 0; p < MAX_PLAYERS; p++) {
        for (int i = 0; i < PIECES_PER_PLAYER; i++) {
            piecePositions[p][i] = -1;
            pieceStates[p][i] = BASE;
        }
    }
}

GameState::GameState(const GameState& other) {
    currentPlayerIndex = other.currentPlayerIndex;
    consecutiveSixes   = other.consecutiveSixes;
    moveNumber         = other.moveNumber;
    for (int p = 0; p < MAX_PLAYERS; p++) {
        for (int i = 0; i < PIECES_PER_PLAYER; i++) {
            piecePositions[p][i] = other.piecePositions[p][i];
            pieceStates[p][i]    = other.pieceStates[p][i];
        }
    }
}

GameState& GameState::operator=(const GameState& other) {
    if (this == &other) return *this;
    currentPlayerIndex = other.currentPlayerIndex;
    consecutiveSixes   = other.consecutiveSixes;
    moveNumber         = other.moveNumber;
    for (int p = 0; p < MAX_PLAYERS; p++) {
        for (int i = 0; i < PIECES_PER_PLAYER; i++) {
            piecePositions[p][i] = other.piecePositions[p][i];
            pieceStates[p][i]    = other.pieceStates[p][i];
        }
    }
    return *this;
}
