#include <iostream>
#include <string>
#include "BSAI25020-Game.h"
#include "BSAI25020-Dice.h"
#include "BSAI25020-Helpers.h"
#include "BSAI25020-Displaying.h"
#include "BSAI25020-Player.h"

int main() {
    Game game;
    Helpers helpers;
    Displaying display(1200, 800, 40);
    Dice dice;

    bool running = true;

    do {
        AppState state = game.getAppState();

        if (state == MENU) {
            int choice = helpers.getMenuChoice();
            switch (choice) {
            case 1: {
                int count = 2;
                std::cout << "Enter number of players (2-6): ";
                std::cin >> count;
                game.startGame(count);
                break;
            }
            case 2: {
                std::string filename;
                std::cout << "Enter save filename: ";
                std::cin >> filename;
                game.loadGame(filename);
                break;
            }
            case 3:
                game.startReplay();
                break;
            case 4:
                running = false;
                break;
            default:
                break;
            }

        } else if (state == PLAYING) {
            int curIdx = game.getCurrentPlayer();
            Player* cur = game.getPlayer(curIdx);
            if (cur == nullptr) {
                running = false;
                break;
            }

            display.drawBoard(game.getBoard());
            display.drawPieces(game.getPlayer(0), game.getPlayerCount());
            display.drawUI(&game);

            char cmd = ' ';
            std::cout << "\n[R]oll [U]ndo [E]redo [S]ave [Q]uit > ";
            std::cin >> cmd;

            switch (cmd) {
            case 'u':
            case 'U':
                game.undoMove();
                break;
            case 'e':
            case 'E':
                game.redoMove();
                break;
            case 's':
            case 'S': {
                std::string fn;
                std::cout << "Filename: ";
                std::cin >> fn;
                game.saveGame(fn);
                break;
            }
            case 'q':
            case 'Q':
                running = false;
                break;
            default: {
                int rollVal = dice.roll();
                display.drawDice(rollVal);

                if (dice.getConsecutiveSixes() >= 3) {
                    std::cout << "Three consecutive sixes! Turn forfeited.\n";
                    game.changeAppState(PLAYING);
                    break;
                }

                if (!Helpers::hasAnyValidMove(cur, rollVal, game.getBoard())) {
                    std::cout << "No valid moves. Turn passes.\n";
                } else {
                    game.movePiece(cur, rollVal);
                }
                break;
            }
            }

        } else if (state == GAMEOVER) {
            std::cout << "\n=== GAME OVER ===\n";
            std::cout << "1=Replay  2=New Game  3=Quit\nChoice: ";
            int c = 0;
            std::cin >> c;
            switch (c) {
            case 1:
                game.startReplay();
                break;
            case 2:
                game.changeAppState(MENU);
                break;
            default:
                running = false;
                break;
            }

        } else if (state == PAUSE) {
            std::cout << "Game paused. Press Enter to resume...\n";
            std::cin.ignore();
            std::cin.get();
            game.changeAppState(PLAYING);
        }

    } while (running);

    std::cout << "Thanks for playing Ludo!\n";
    return 0;
}
