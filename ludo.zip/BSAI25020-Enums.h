#pragma once

enum Colour {
    RED,
    GREEN,
    YELLOW,
    BLUE,
    PURPLE,
    ORANGE,
    NONE_COLOUR
};

enum PieceState {
    BASE,
    ACTIVE,
    HOME_COL,
    FINISHED
};

enum AppState {
    MENU,
    PLAYING,
    PAUSE,
    GAMEOVER
};

static const int MAX_PIECES = 4;
