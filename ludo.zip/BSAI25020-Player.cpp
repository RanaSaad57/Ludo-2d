#include "BSAI25020-Player.h"

Player::Player() : name(""), colour(NONE_COLOUR), isHuman(true) {
    for (int i = 0; i < MAX_PIECES; i++) {
        pieces[i] = Piece(i, NONE_COLOUR);
    }
}

Player::Player(const std::string& n, Colour c, bool human)
    : name(n), colour(c), isHuman(human) {
    for (int i = 0; i < MAX_PIECES; i++) {
        pieces[i] = Piece(i, c);
    }
}

Player::~Player() {}

std::string Player::getName() const {
    return name;
}

Colour Player::getColour() const {
    return colour;
}

Piece* Player::getPiece(int i) {
    if (i < 0 || i >= MAX_PIECES) return nullptr;
    return &pieces[i];
}

const Piece* Player::getPiece(int i) const {
    if (i < 0 || i >= MAX_PIECES) return nullptr;
    return &pieces[i];
}

bool Player::allFinished() const {
    for (int i = 0; i < MAX_PIECES; i++) {
        if (!pieces[i].isFinished()) return false;
    }
    return true;
}

int Player::getActivePieceCount() const {
    int count = 0;
    for (int i = 0; i < MAX_PIECES; i++) {
        if (pieces[i].getState() == ACTIVE || pieces[i].getState() == HOME_COL) {
            count++;
        }
    }
    return count;
}

bool Player::getIsHuman() const {
    return isHuman;
}
