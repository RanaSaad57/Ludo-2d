#pragma once
#include "raylib.h"
#include "BSAI25013-Enums.h"
using namespace std;

class Board;
class Player;
class Game;
class Piece;

class Displaying {
private:
    int SW, SH, CS, OX, OY, BS;

    Texture2D boardTex;
    Texture2D pawnTex[4];

    Color lC_Red;
    Color lC_Green;
    Color lC_Yellow;
    Color lC_Blue;

    Color     toRayColor(Colour c)                           const;
    Vector2   trackCellToScreen(int tp)                      const;
    Vector2   homeColToScreen(Colour c, int posInHC)         const;
    Vector2   baseCellToScreen(Colour c, int pieceIdx)       const;
    Vector2   cellIdToScreen(int id)                         const;
    Texture2D getPawnTex(Colour c)                           const;

    void drawPieceSprite(Vector2 pos, Colour c, bool selected) const;
    Vector2 boardCell(float col, float row)                   const;

public:
    Displaying();
    Displaying(int w, int h, int cs);
    ~Displaying();

    void drawBoard()                                               const;
    void drawPieces(const Game* g, int selPiece, int selPlayer)   const;
    void drawDice(int roll, bool rolled)                          const;
    void drawUI(const Game* g)                                    const;
    void drawMenu()                                               const;
    void drawGameOver(const Game* g)                              const;

    int     getCS()                                               const;
    Vector2 getPieceScreenPos(int cellId)                         const;
    bool    isClickOnPiece(Vector2 mouse, Vector2 piecePos)       const;
};
