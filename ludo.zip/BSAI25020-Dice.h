#pragma once

class Dice {
private:
    int lastRoll;
    int consecutiveSixes;
    int totalMove;

public:
    Dice();

    int roll();
    int getTotalMove() const;
    int getLastRoll() const;
    int getConsecutiveSixes() const;
    void reset();
};
