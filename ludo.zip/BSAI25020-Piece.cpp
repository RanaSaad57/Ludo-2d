#include "BSAI25020-Piece.h"

Piece::Piece() : pieceNo(0), colour(NONE_COLOUR), position(-1), state(BASE) {}

Piece::Piece(int no, Colour c) : pieceNo(no), colour(c), position(-1), state(BASE) {}

int Piece::getPosition() const {
    return position;
}

int Piece::getPieceN() const {
    return pieceNo;
}

Colour Piece::getColour() const {
    return colour;
}

PieceState Piece::getState() const {
    return state;
}

void Piece::setState(PieceState s) {
    state = s;
}

void Piece::setPosition(int pos) {
    position = pos;
}

bool Piece::isFinished() const {
    return state == FINISHED;
}

void Piece::reset() {
    position = -1;
    state = BASE;
}
