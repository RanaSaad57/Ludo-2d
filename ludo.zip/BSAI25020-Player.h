#pragma once
#include <string>
#include "BSAI25020-Piece.h"

class Player {
protected:
    std::string name;
    Colour colour;
    Piece pieces[MAX_PIECES];
    bool isHuman;

public:
    Player();
    Player(const std::string& n, Colour c, bool human = true);
    virtual ~Player();

    std::string getName() const;
    Colour getColour() const;
    Piece* getPiece(int i);
    const Piece* getPiece(int i) const;
    bool allFinished() const;
    int getActivePieceCount() const;

    virtual int getMove() = 0;

    bool getIsHuman() const;
};
