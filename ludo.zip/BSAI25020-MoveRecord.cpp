#include "BSAI25020-MoveRecord.h"

MoveRecord::MoveRecord()
    : pieceNo(-1), playerId(-1), source(-1), dest(-1),
      capturedPieceNo(-1), capturedPlayerId(-1), diceValue(0), wasCapture(false) {}

MoveRecord::MoveRecord(int pNo, int pId, int src, int dst, int diceVal,
                       bool capture, int capPieceNo, int capPlayerId)
    : pieceNo(pNo), playerId(pId), source(src), dest(dst),
      capturedPieceNo(capPieceNo), capturedPlayerId(capPlayerId),
      diceValue(diceVal), wasCapture(capture) {}

bool MoveRecord::wasCapture_() const {
    return wasCapture;
}
