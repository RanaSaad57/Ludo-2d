#include "BSAI25020-Dice.h"
#include <cstdlib>
#include <ctime>

Dice::Dice() : lastRoll(0), consecutiveSixes(0), totalMove(0) {
    srand((unsigned int)time(nullptr));
}

int Dice::roll() {
    lastRoll = (rand() % 6) + 1;
    totalMove += lastRoll;

    if (lastRoll == 6) {
        consecutiveSixes++;
    } else {
        consecutiveSixes = 0;
    }
    return lastRoll;
}

int Dice::getTotalMove() const {
    return totalMove;
}

int Dice::getLastRoll() const {
    return lastRoll;
}

int Dice::getConsecutiveSixes() const {
    return consecutiveSixes;
}

void Dice::reset() {
    totalMove = 0;

}
