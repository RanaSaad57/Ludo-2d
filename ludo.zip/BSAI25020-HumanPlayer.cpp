#include "BSAI25020-HumanPlayer.h"

HumanPlayer::HumanPlayer() : Player() {
    isHuman = true;
}

HumanPlayer::HumanPlayer(const std::string& n, Colour c) : Player(n, c, true) {}

HumanPlayer::~HumanPlayer() {}

int HumanPlayer::getMove() {
    return -1;
}
