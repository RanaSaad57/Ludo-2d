#pragma once
#include <vector>
#include "BSAI25020-Cell.h"
#include "BSAI25020-Enums.h"

static const int TRACK_SIZE      = 52;
static const int HOME_COL_LEN    = 6;
static const int MAX_COLOURS     = 6;
static const int CENTRE_CELL_ID  = 88;
static const int BASE_START_ID   = 89;
static const int TOTAL_CELLS     = 113;

class Board {
private:
    std::vector<Cell> cells;
    int cellCount;

    void initBoard();
    void markSafeSquares();
    void markHomeColumns();
    void markBaseCells();

public:
    Board();

    Cell* getCell(int id);
    const Cell* getCell(int id) const;

    bool isSafeSquare(int pos) const;
    bool isHomeColumn(int pos, Colour c) const;
    int getStartPosition(Colour c) const;
    int getHomeColumnEntry(Colour c) const;

    int trackPosToCell(int trackPos) const;

    int getDestination(int currentCellId, int roll, Colour c) const;

    int getCellCount() const;

    int getBaseCellId(Colour c, int pieceIndex) const;

    int getCentreCellId() const;
};
